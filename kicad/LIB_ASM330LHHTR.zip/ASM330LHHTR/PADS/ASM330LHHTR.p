*PADS-LIBRARY-PART-TYPES-V9*

ASM330LHHTR LSM6DS3USTR I ANA 9 1 0 0 0
TIMESTAMP 2026.10.02.18.38.32
"Manufacturer_Name" STMicroelectronics
"Manufacturer_Part_Number" ASM330LHHTR
"Mouser Part Number" 511-ASM330LHHTR
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/STMicroelectronics/ASM330LHHTR?qs=lc2O%252BfHJPVYgP8P9MzExKQ%3D%3D
"Arrow Part Number" ASM330LHHTR
"Arrow Price/Stock" https://www.arrow.com/en/products/asm330lhhtr/stmicroelectronics?utm_currency=USD&region=europe
"Description" STMICROELECTRONICS - ASM330LHHTR - MEMS MOD, 3-AXIS GYROSCOPE/ACCELEROMETER
"Datasheet Link" https://www.st.com/resource/en/datasheet/asm330lhh.pdf
"Geometry.Height" 0.86mm
GATE 1 14 0
ASM330LHHTR
1 0 U SDO/SA0
2 0 U RES_1
3 0 U RES_2
4 0 U INT1
5 0 U VDDIO
6 0 U GND_1
7 0 U GND_2
8 0 U VDD
9 0 U INT2
10 0 U NC_1
11 0 U NC_2
12 0 U CS
13 0 U SCL
14 0 U SDA

*END*
*REMARK* SamacSys ECAD Model
1429923/2179087/2.50/14/2/Integrated Circuit
