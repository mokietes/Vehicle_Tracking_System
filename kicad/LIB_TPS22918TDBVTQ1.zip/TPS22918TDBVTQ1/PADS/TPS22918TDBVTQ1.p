*PADS-LIBRARY-PART-TYPES-V9*

TPS22918TDBVTQ1 SOT95P280X145-6N I ANA 9 1 0 0 0
TIMESTAMP 2026.10.02.17.36.22
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" TPS22918TDBVTQ1
"Mouser Part Number" 595-TPS22918TDBVTQ1
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/TPS22918TDBVTQ1?qs=AvgxZrxb8y2k10t5sHUssQ%3D%3D
"Arrow Part Number" TPS22918TDBVTQ1
"Arrow Price/Stock" https://www.arrow.com/en/products/tps22918tdbvtq1/texas-instruments.html?utm_currency=USD&region=nac
"Description" 5.5V, 2A, 52m Automotive High-Side Load Switch with Adjustable Rise Time & Quick Output Discharge
"Datasheet Link" http://www.ti.com/lit/ds/symlink/tps22918-q1.pdf
"Geometry.Height" 1.45mm
GATE 1 6 0
TPS22918TDBVTQ1
1 0 U VIN
2 0 U GND
3 0 U ON
6 0 U VOUT
5 0 U QOD
4 0 U CT

*END*
*REMARK* SamacSys ECAD Model
690892/2179087/2.50/6/4/Integrated Circuit
